public interface FeedOfIntValues {
	public boolean hasNext();
	public int getNextIntValue();
}

